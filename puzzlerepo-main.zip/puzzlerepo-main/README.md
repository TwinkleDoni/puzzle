# puzzlerepo
Curiosity and analytical skills are assessed by solving the mystery. This is simple to find the mystery by analyzing the clues carefully and eliminating people.
Implemented using:
 - tkinter in python
 - html,css,javascript
 - mysql-connect-python
